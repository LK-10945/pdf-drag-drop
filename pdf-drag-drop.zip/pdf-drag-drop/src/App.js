import React from 'react';
import PDFDropZone from './PDFDropZone';

function App() {
  return (
    <div className="App">
      <h1>Class Submissions Page Upload</h1>
      <PDFDropZone />
    </div>
  );
}

export default App;
